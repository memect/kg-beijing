UPDATE dish
SET name='仰望星空', data=data #- '{人数}'
WHERE name='仰望星空';
