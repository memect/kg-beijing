DELETE FROM dish
WHERE name = '仰望星空';
