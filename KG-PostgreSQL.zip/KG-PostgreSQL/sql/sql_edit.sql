UPDATE dish
SET name='仰望星空', data='{"人数": 10, "时间": "30分钟"}'
WHERE name='仰望星空';
