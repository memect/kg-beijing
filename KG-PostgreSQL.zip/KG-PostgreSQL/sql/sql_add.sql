INSERT INTO dish
VALUES ('仰望星空', '{"人数": 2, "时间": "30分钟"}');
